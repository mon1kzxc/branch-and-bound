﻿
namespace Черновик
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Way_button = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.Creat_Work = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.AD = new System.Windows.Forms.TextBox();
            this.AC = new System.Windows.Forms.TextBox();
            this.AB = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.CD = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.CB = new System.Windows.Forms.TextBox();
            this.CA = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.BD = new System.Windows.Forms.TextBox();
            this.BC = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.BA = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.ED = new System.Windows.Forms.TextBox();
            this.EC = new System.Windows.Forms.TextBox();
            this.EB = new System.Windows.Forms.TextBox();
            this.EA = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.DC = new System.Windows.Forms.TextBox();
            this.Db = new System.Windows.Forms.TextBox();
            this.DA = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.DE = new System.Windows.Forms.TextBox();
            this.CE = new System.Windows.Forms.TextBox();
            this.BE = new System.Windows.Forms.TextBox();
            this.AE = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.Answer = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Way_button
            // 
            this.Way_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Way_button.Location = new System.Drawing.Point(12, 148);
            this.Way_button.Name = "Way_button";
            this.Way_button.Size = new System.Drawing.Size(189, 34);
            this.Way_button.TabIndex = 1;
            this.Way_button.Text = "Shortest road";
            this.Way_button.UseVisualStyleBackColor = true;
            this.Way_button.Click += new System.EventHandler(this.Way_button_Click);
            // 
            // Clear
            // 
            this.Clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Clear.Location = new System.Drawing.Point(278, 76);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(111, 35);
            this.Clear.TabIndex = 2;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = true;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Creat_Work
            // 
            this.Creat_Work.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Creat_Work.Location = new System.Drawing.Point(278, 33);
            this.Creat_Work.Name = "Creat_Work";
            this.Creat_Work.Size = new System.Drawing.Size(111, 35);
            this.Creat_Work.TabIndex = 3;
            this.Creat_Work.Text = "Сompil";
            this.Creat_Work.UseVisualStyleBackColor = true;
            this.Creat_Work.Click += new System.EventHandler(this.Creat_Work_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(52, 7);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(38, 20);
            this.textBox1.TabIndex = 7;
            this.textBox1.Text = "A";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(126, 7);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(38, 20);
            this.textBox4.TabIndex = 9;
            this.textBox4.Text = "C";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(89, 7);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(38, 20);
            this.textBox5.TabIndex = 8;
            this.textBox5.Text = "B";
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(163, 7);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(38, 20);
            this.textBox6.TabIndex = 10;
            this.textBox6.Text = "D";
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AD
            // 
            this.AD.Location = new System.Drawing.Point(163, 33);
            this.AD.Name = "AD";
            this.AD.Size = new System.Drawing.Size(38, 20);
            this.AD.TabIndex = 15;
            this.AD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AC
            // 
            this.AC.Location = new System.Drawing.Point(126, 33);
            this.AC.Name = "AC";
            this.AC.Size = new System.Drawing.Size(38, 20);
            this.AC.TabIndex = 14;
            this.AC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AB
            // 
            this.AB.Location = new System.Drawing.Point(89, 33);
            this.AB.Name = "AB";
            this.AB.Size = new System.Drawing.Size(38, 20);
            this.AB.TabIndex = 13;
            this.AB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox9.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox9.Location = new System.Drawing.Point(52, 33);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(38, 20);
            this.textBox9.TabIndex = 12;
            this.textBox9.Text = "0";
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(10, 33);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(38, 20);
            this.textBox10.TabIndex = 11;
            this.textBox10.Text = "А";
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // CD
            // 
            this.CD.Location = new System.Drawing.Point(163, 69);
            this.CD.Name = "CD";
            this.CD.Size = new System.Drawing.Size(38, 20);
            this.CD.TabIndex = 25;
            this.CD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox12.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox12.Location = new System.Drawing.Point(126, 69);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(38, 20);
            this.textBox12.TabIndex = 24;
            this.textBox12.Text = "0";
            this.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // CB
            // 
            this.CB.Location = new System.Drawing.Point(89, 69);
            this.CB.Name = "CB";
            this.CB.Size = new System.Drawing.Size(38, 20);
            this.CB.TabIndex = 23;
            this.CB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // CA
            // 
            this.CA.Location = new System.Drawing.Point(52, 69);
            this.CA.Name = "CA";
            this.CA.Size = new System.Drawing.Size(38, 20);
            this.CA.TabIndex = 22;
            this.CA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(10, 69);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(38, 20);
            this.textBox15.TabIndex = 21;
            this.textBox15.Text = "C";
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BD
            // 
            this.BD.Location = new System.Drawing.Point(163, 51);
            this.BD.Name = "BD";
            this.BD.Size = new System.Drawing.Size(38, 20);
            this.BD.TabIndex = 20;
            this.BD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BC
            // 
            this.BC.Location = new System.Drawing.Point(126, 51);
            this.BC.Name = "BC";
            this.BC.Size = new System.Drawing.Size(38, 20);
            this.BC.TabIndex = 19;
            this.BC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox18
            // 
            this.textBox18.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox18.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox18.Location = new System.Drawing.Point(89, 51);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(38, 20);
            this.textBox18.TabIndex = 18;
            this.textBox18.Text = "0";
            this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BA
            // 
            this.BA.Location = new System.Drawing.Point(52, 51);
            this.BA.Name = "BA";
            this.BA.Size = new System.Drawing.Size(38, 20);
            this.BA.TabIndex = 17;
            this.BA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(10, 51);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(38, 20);
            this.textBox20.TabIndex = 16;
            this.textBox20.Text = "B";
            this.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ED
            // 
            this.ED.Location = new System.Drawing.Point(163, 106);
            this.ED.Name = "ED";
            this.ED.Size = new System.Drawing.Size(38, 20);
            this.ED.TabIndex = 35;
            this.ED.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // EC
            // 
            this.EC.Location = new System.Drawing.Point(126, 106);
            this.EC.Name = "EC";
            this.EC.Size = new System.Drawing.Size(38, 20);
            this.EC.TabIndex = 34;
            this.EC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // EB
            // 
            this.EB.Location = new System.Drawing.Point(89, 106);
            this.EB.Name = "EB";
            this.EB.Size = new System.Drawing.Size(38, 20);
            this.EB.TabIndex = 33;
            this.EB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // EA
            // 
            this.EA.Location = new System.Drawing.Point(52, 106);
            this.EA.Name = "EA";
            this.EA.Size = new System.Drawing.Size(38, 20);
            this.EA.TabIndex = 32;
            this.EA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(10, 106);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(38, 20);
            this.textBox25.TabIndex = 31;
            this.textBox25.Text = "E";
            this.textBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox26
            // 
            this.textBox26.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox26.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox26.Location = new System.Drawing.Point(163, 87);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(38, 20);
            this.textBox26.TabIndex = 30;
            this.textBox26.Text = "0";
            this.textBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DC
            // 
            this.DC.Location = new System.Drawing.Point(126, 87);
            this.DC.Name = "DC";
            this.DC.Size = new System.Drawing.Size(38, 20);
            this.DC.TabIndex = 29;
            this.DC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Db
            // 
            this.Db.Location = new System.Drawing.Point(89, 87);
            this.Db.Name = "Db";
            this.Db.Size = new System.Drawing.Size(38, 20);
            this.Db.TabIndex = 28;
            this.Db.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DA
            // 
            this.DA.Location = new System.Drawing.Point(52, 87);
            this.DA.Name = "DA";
            this.DA.Size = new System.Drawing.Size(38, 20);
            this.DA.TabIndex = 27;
            this.DA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(10, 87);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(38, 20);
            this.textBox30.TabIndex = 26;
            this.textBox30.Text = "D";
            this.textBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox2.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.textBox2.Location = new System.Drawing.Point(200, 106);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(38, 20);
            this.textBox2.TabIndex = 41;
            this.textBox2.Text = "0";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DE
            // 
            this.DE.Location = new System.Drawing.Point(200, 87);
            this.DE.Name = "DE";
            this.DE.Size = new System.Drawing.Size(38, 20);
            this.DE.TabIndex = 40;
            this.DE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // CE
            // 
            this.CE.Location = new System.Drawing.Point(200, 69);
            this.CE.Name = "CE";
            this.CE.Size = new System.Drawing.Size(38, 20);
            this.CE.TabIndex = 39;
            this.CE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // BE
            // 
            this.BE.Location = new System.Drawing.Point(200, 51);
            this.BE.Name = "BE";
            this.BE.Size = new System.Drawing.Size(38, 20);
            this.BE.TabIndex = 38;
            this.BE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AE
            // 
            this.AE.Location = new System.Drawing.Point(200, 33);
            this.AE.Name = "AE";
            this.AE.Size = new System.Drawing.Size(38, 20);
            this.AE.TabIndex = 37;
            this.AE.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(200, 7);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(38, 20);
            this.textBox35.TabIndex = 36;
            this.textBox35.Text = "E";
            this.textBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Answer
            // 
            this.Answer.Font = new System.Drawing.Font("Pecita", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Answer.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Answer.Location = new System.Drawing.Point(234, 151);
            this.Answer.Name = "Answer";
            this.Answer.Size = new System.Drawing.Size(155, 34);
            this.Answer.TabIndex = 42;
            this.Answer.Text = "ANSWER";
            this.Answer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Answer.UseWaitCursor = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(467, 212);
            this.Controls.Add(this.Answer);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.DE);
            this.Controls.Add(this.CE);
            this.Controls.Add(this.BE);
            this.Controls.Add(this.AE);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.ED);
            this.Controls.Add(this.EC);
            this.Controls.Add(this.EB);
            this.Controls.Add(this.EA);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.DC);
            this.Controls.Add(this.Db);
            this.Controls.Add(this.DA);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.CD);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.CB);
            this.Controls.Add(this.CA);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.BD);
            this.Controls.Add(this.BC);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.BA);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.AD);
            this.Controls.Add(this.AC);
            this.Controls.Add(this.AB);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Creat_Work);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Way_button);
            this.Name = "Form2";
            this.Text = "App";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Way_button;
        private System.Windows.Forms.Button Clear;
        private System.Windows.Forms.Button Creat_Work;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox AD;
        private System.Windows.Forms.TextBox AC;
        private System.Windows.Forms.TextBox AB;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox CD;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox CB;
        private System.Windows.Forms.TextBox CA;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox BD;
        private System.Windows.Forms.TextBox BC;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox BA;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox ED;
        private System.Windows.Forms.TextBox EC;
        private System.Windows.Forms.TextBox EB;
        private System.Windows.Forms.TextBox EA;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox DC;
        private System.Windows.Forms.TextBox Db;
        private System.Windows.Forms.TextBox DA;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox DE;
        private System.Windows.Forms.TextBox CE;
        private System.Windows.Forms.TextBox BE;
        private System.Windows.Forms.TextBox AE;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox Answer;
    }
}