﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Черновик
{
    public partial class Form2 : Form
    {
        static int INF = int.MaxValue;
        static int[,] adjacencyMatrix;

        static int[] bestPath;
        static int bestDistance = INF;

        static int CalculateDistance(int[] path)
        {
            int distance = 0;
            for (int i = 0; i < path.Length - 1; i++)
            {
                int fromCity = path[i];
                int toCity = path[i + 1];
                distance += adjacencyMatrix[fromCity, toCity];
            }
            distance += adjacencyMatrix[path[path.Length - 1], path[0]];
            return distance;
        }
        static void BranchAndBound(int[] path, int level, int bound)
        {
            if (level == path.Length - 1)
            {
                int distance = CalculateDistance(path);
                if (distance < bestDistance)
                {
                    bestDistance = distance;
                    Array.Copy(path, bestPath, path.Length);
                }
                return;
            }

            for (int i = level + 1; i < path.Length; i++)
            {
                // Проверяем, можно ли продолжить ветвление
                if (adjacencyMatrix[path[level], path[i]] != 0 && bound < bestDistance)
                {
                    // Пытаемся определить верхнюю границу для текущего уровня
                    // Это можно сделать, например, с помощью оставшегося пути
                    int newBound = bound + CalculateLowerBound(path, level);
                    if (newBound < bestDistance) // Если верхняя граница обещает лучший результат
                    {
                        Swap(ref path[level + 1], ref path[i]);
                        BranchAndBound(path, level + 1, bound + adjacencyMatrix[path[level], path[level + 1]]);
                        Swap(ref path[level + 1], ref path[i]);
                    }
                }
            }
        }

        static int CalculateLowerBound(int[] path, int level)
        {
            // Пример расчета нижней границы:
            // Расстояние от текущего города до оставшихся
            int lowerBound = 0;
            for (int i = level + 1; i < path.Length; i++)
            {
                lowerBound += GetClosestCityDistance(path[i], path, level);
            }
            return lowerBound;
        }

        static int GetClosestCityDistance(int city, int[] path, int level)
        {
            int minDistance = INF;
            for (int i = level; i < path.Length; i++)
            {
                if (adjacencyMatrix[city, path[i]] < minDistance)
                    minDistance = adjacencyMatrix[city, path[i]];
            }
            return minDistance;
        }


        static void Swap<T>(ref T a, ref T b)
        {
            T temp = a;
            a = b;
            b = temp;
        }

        public Form2()
        {
            InitializeComponent();
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            Answer.Clear();

            TextBox[] matrixTextBoxes = { AB, AC, AD, AE, BA, BC, BD, BE, CA, CB, CD, CE, DA, Db, DC, DE, EA, EB, EC, ED };

            foreach (TextBox textBox in matrixTextBoxes)
            {
                textBox.Clear();
            }
        }


        private void Creat_Work_Click(object sender, EventArgs e)
        {
            // Проверяем, заполнены ли все поля матрицы
            TextBox[] matrixTextBoxes = { AB, AC, AD, AE, BA, BC, BD, BE, CA, CB, CD, CE, DA, Db, DC, DE, EA, EB, EC, ED };
            foreach (TextBox textBox in matrixTextBoxes)
            {
                if (string.IsNullOrWhiteSpace(textBox.Text))
                {
                    MessageBox.Show("Заполните все поля матрицы перед созданием матрицы.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Прекращаем выполнение метода, если есть пустые поля
                }
            }

            int numOfCities = 5;
            adjacencyMatrix = new int[numOfCities, numOfCities];

            for (int i = 0; i < matrixTextBoxes.Length; i++)
            {
                int row = i / numOfCities;
                int col = i % numOfCities;
                adjacencyMatrix[row, col] = Convert.ToInt32(matrixTextBoxes[i].Text);
            }
        }


        private void Way_button_Click(object sender, EventArgs e)
        {
            int numOfCities = 5;
            int[] path = Enumerable.Range(0, numOfCities).ToArray();
            bestPath = new int[numOfCities];

            // Проверяем, заполнены ли все поля матрицы
            TextBox[] matrixTextBoxes = { AB, AC, AD, AE, BA, BC, BD, BE, CA, CB, CD, CE, DA, Db, DC, DE, EA, EB, EC, ED };
            foreach (TextBox textBox in matrixTextBoxes)
            {
                if (string.IsNullOrWhiteSpace(textBox.Text))
                {
                    MessageBox.Show("Заполните все поля матрицы перед поиском кратчайшего пути.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; // Прекращаем выполнение метода, если есть пустые поля
                }
            }

            BranchAndBound(path, 0, 0);

            Answer.Text += bestDistance;
        }

    }
}
